﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineShoppingManagement.Services
{
    public class CartService
    {
    }
}